import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { motion } from 'framer-motion';
import { Droplets, Info, AlertTriangle, BarChart2, FileText, Globe2 } from 'lucide-react';

export default function Navbar() {
  const { language, toggleLanguage } = useLanguage();
  const location = useLocation();

  const navItems = {
    id: [
      { path: '/', label: 'Beranda', icon: Droplets },
      { path: '/definisi', label: 'Definisi', icon: Info },
      { path: '/penyebab', label: 'Penyebab', icon: AlertTriangle },
      { path: '/dampak', label: 'Dampak', icon: BarChart2 },
      { path: '/karakteristik', label: 'Karakteristik', icon: FileText },
    ],
    en: [
      { path: '/', label: 'Home', icon: Droplets },
      { path: '/definisi', label: 'Definition', icon: Info },
      { path: '/penyebab', label: 'Causes', icon: AlertTriangle },
      { path: '/dampak', label: 'Impacts', icon: BarChart2 },
      { path: '/karakteristik', label: 'Characteristics', icon: FileText },
    ]
  };

  return (
    <nav className="bg-blue-900/80 backdrop-blur-sm fixed w-full z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            {navItems[language].map(({ path, label, icon: Icon }) => (
              <Link
                key={path}
                to={path}
                className="relative group"
              >
                <div className="flex items-center space-x-2 text-white hover:text-blue-300 transition-colors">
                  <Icon size={20} />
                  <span>{label}</span>
                </div>
                {location.pathname === path && (
                  <motion.div
                    layoutId="underline"
                    className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-400"
                  />
                )}
              </Link>
            ))}
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleLanguage}
            className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-blue-700 text-white hover:bg-blue-600 transition-colors"
          >
            <Globe2 size={20} />
            <span>{language === 'id' ? 'English' : 'Indonesia'}</span>
          </motion.button>
        </div>
      </div>
    </nav>
  );
}