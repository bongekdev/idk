import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { motion } from 'framer-motion';
import Scene3D from '../components/Scene3D';

const content = {
  id: {
    title: 'Definisi Pencemaran Air',
    sections: [
      {
        title: 'Apa itu Pencemaran Air?',
        content: 'Pencemaran air adalah masuknya zat, energi, atau komponen lain ke dalam air yang menyebabkan kualitas air menurun hingga tingkat tertentu yang menyebabkan air tidak berfungsi lagi sesuai dengan peruntukannya.'
      },
      {
        title: 'Indikator Pencemaran Air',
        content: 'Beberapa indikator pencemaran air meliputi perubahan suhu, perubahan pH, perubahan warna, bau dan rasa, timbulnya endapan, dan adanya mikroorganisme berbahaya.'
      },
      {
        title: 'Standar Kualitas Air',
        content: 'Menurut Peraturan Pemerintah Indonesia, air bersih harus memenuhi persyaratan fisik, kimia, dan biologis. Parameter ini mencakup kejernihan, bebas dari zat berbahaya, dan tidak mengandung bakteri patogen.'
      }
    ]
  },
  en: {
    title: 'Definition of Water Pollution',
    sections: [
      {
        title: 'What is Water Pollution?',
        content: 'Water pollution is the contamination of water bodies by substances, energy, or other components that cause water quality to decrease to a certain level, making it no longer function according to its intended purpose.'
      },
      {
        title: 'Water Pollution Indicators',
        content: 'Several indicators of water pollution include changes in temperature, pH changes, changes in color, odor and taste, the emergence of sediments, and the presence of harmful microorganisms.'
      },
      {
        title: 'Water Quality Standards',
        content: 'According to Indonesian Government Regulations, clean water must meet physical, chemical, and biological requirements. These parameters include clarity, freedom from harmful substances, and absence of pathogenic bacteria.'
      }
    ]
  }
};

export default function Definition() {
  const { language } = useLanguage();
  const text = content[language];

  return (
    <div className="min-h-screen py-16">
      <div className="section-container">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="page-title"
        >
          {text.title}
        </motion.h1>

        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-8">
            {text.sections.map((section, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
                className="card"
              >
                <h2 className="text-2xl font-bold mb-4 text-blue-300">
                  {section.title}
                </h2>
                <p className="text-lg leading-relaxed">
                  {section.content}
                </p>
              </motion.div>
            ))}
          </div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            className="sticky top-24"
          >
            <Scene3D />
          </motion.div>
        </div>
      </div>
    </div>
  );
}