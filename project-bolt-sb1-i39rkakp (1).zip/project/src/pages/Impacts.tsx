import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { motion } from 'framer-motion';
import Scene3D from '../components/Scene3D';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

const content = {
  id: {
    title: 'Dampak Pencemaran Air',
    description: 'Pencemaran air memiliki dampak serius terhadap kesehatan manusia, ekosistem, dan ekonomi Indonesia.',
    sections: [
      {
        title: 'Dampak Kesehatan',
        content: 'Konsumsi air tercemar dapat menyebabkan berbagai penyakit seperti diare, kolera, dan tifus. Setiap tahun, ribuan kasus penyakit terkait air tercemar dilaporkan di Indonesia.'
      },
      {
        title: 'Dampak Ekologis',
        content: 'Pencemaran air merusak ekosistem akuatik, menyebabkan kematian ikan dan organisme air lainnya. Hal ini juga mengancam keberagaman hayati di perairan Indonesia.'
      },
      {
        title: 'Dampak Ekonomi',
        content: 'Pencemaran air meningkatkan biaya pengolahan air minum dan mengurangi pendapatan dari sektor perikanan dan pariwisata.'
      }
    ],
    chartTitle: 'Dampak Ekonomi Pencemaran Air (dalam Triliun Rupiah/Tahun)',
    chartData: [
      { name: 'Biaya Kesehatan', value: 25 },
      { name: 'Kerugian Perikanan', value: 15 },
      { name: 'Penurunan Pariwisata', value: 10 },
      { name: 'Biaya Pengolahan Air', value: 20 }
    ]
  },
  en: {
    title: 'Impacts of Water Pollution',
    description: 'Water pollution has serious impacts on human health, ecosystems, and the Indonesian economy.',
    sections: [
      {
        title: 'Health Impacts',
        content: 'Consumption of polluted water can cause various diseases such as diarrhea, cholera, and typhoid. Thousands of water pollution-related illness cases are reported in Indonesia annually.'
      },
      {
        title: 'Ecological Impacts',
        content: 'Water pollution damages aquatic ecosystems, causing death of fish and other aquatic organisms. This also threatens biodiversity in Indonesian waters.'
      },
      {
        title: 'Economic Impacts',
        content: 'Water pollution increases drinking water treatment costs and reduces income from fisheries and tourism sectors.'
      }
    ],
    chartTitle: 'Economic Impact of Water Pollution (in Trillion Rupiah/Year)',
    chartData: [
      { name: 'Health Costs', value: 25 },
      { name: 'Fishery Losses', value: 15 },
      { name: 'Tourism Decline', value: 10 },
      { name: 'Water Treatment Costs', value: 20 }
    ]
  }
};

const COLORS = ['#60A5FA', '#34D399', '#F472B6', '#FBBF24'];

export default function Impacts() {
  const { language } = useLanguage();
  const text = content[language];

  return (
    <div className="min-h-screen py-16">
      <div className="section-container">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="page-title"
        >
          {text.title}
        </motion.h1>

        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-white text-lg"
            >
              {text.description}
            </motion.p>

            {text.sections.map((section, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
                className="card"
              >
                <h2 className="text-2xl font-bold mb-4 text-blue-300">
                  {section.title}
                </h2>
                <p className="text-lg leading-relaxed">
                  {section.content}
                </p>
              </motion.div>
            ))}

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="card"
            >
              <h3 className="text-xl font-bold mb-4 text-blue-300">{text.chartTitle}</h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={text.chartData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {text.chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            className="sticky top-24"
          >
            <Scene3D />
          </motion.div>
        </div>
      </div>
    </div>
  );
}