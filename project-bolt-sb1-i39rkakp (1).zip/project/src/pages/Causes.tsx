import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { motion } from 'framer-motion';
import Scene3D from '../components/Scene3D';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const content = {
  id: {
    title: 'Penyebab Pencemaran Air',
    description: 'Pencemaran air di Indonesia disebabkan oleh berbagai faktor, baik dari aktivitas industri maupun domestik.',
    sections: [
      {
        title: 'Limbah Industri',
        content: 'Pembuangan limbah industri tanpa pengolahan yang tepat menjadi penyebab utama pencemaran air. Industri tekstil, kertas, dan pertambangan adalah kontributor terbesar.'
      },
      {
        title: 'Limbah Domestik',
        content: 'Sampah rumah tangga dan air limbah domestik yang dibuang langsung ke sungai tanpa pengolahan menyebabkan pencemaran air yang serius.'
      },
      {
        title: 'Pertanian',
        content: 'Penggunaan pestisida dan pupuk kimia yang berlebihan mencemari sumber air tanah dan permukaan.'
      }
    ],
    chartTitle: 'Sumber Pencemaran Air di Indonesia',
    chartData: [
      { name: 'Limbah Industri', percentage: 45 },
      { name: 'Limbah Domestik', percentage: 35 },
      { name: 'Pertanian', percentage: 15 },
      { name: 'Lainnya', percentage: 5 }
    ]
  },
  en: {
    title: 'Causes of Water Pollution',
    description: 'Water pollution in Indonesia is caused by various factors, both from industrial and domestic activities.',
    sections: [
      {
        title: 'Industrial Waste',
        content: 'Improper disposal of industrial waste is a major cause of water pollution. Textile, paper, and mining industries are the biggest contributors.'
      },
      {
        title: 'Domestic Waste',
        content: 'Household waste and domestic wastewater discharged directly into rivers without treatment cause serious water pollution.'
      },
      {
        title: 'Agriculture',
        content: 'Excessive use of pesticides and chemical fertilizers pollutes groundwater and surface water sources.'
      }
    ],
    chartTitle: 'Sources of Water Pollution in Indonesia',
    chartData: [
      { name: 'Industrial Waste', percentage: 45 },
      { name: 'Domestic Waste', percentage: 35 },
      { name: 'Agriculture', percentage: 15 },
      { name: 'Others', percentage: 5 }
    ]
  }
};

export default function Causes() {
  const { language } = useLanguage();
  const text = content[language];

  return (
    <div className="min-h-screen py-16">
      <div className="section-container">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="page-title"
        >
          {text.title}
        </motion.h1>

        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-white text-lg"
            >
              {text.description}
            </motion.p>

            {text.sections.map((section, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
                className="card"
              >
                <h2 className="text-2xl font-bold mb-4 text-blue-300">
                  {section.title}
                </h2>
                <p className="text-lg leading-relaxed">
                  {section.content}
                </p>
              </motion.div>
            ))}

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="card"
            >
              <h3 className="text-xl font-bold mb-4 text-blue-300">{text.chartTitle}</h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={text.chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="percentage" fill="#60A5FA" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            className="sticky top-24"
          >
            <Scene3D />
          </motion.div>
        </div>
      </div>
    </div>
  );
}