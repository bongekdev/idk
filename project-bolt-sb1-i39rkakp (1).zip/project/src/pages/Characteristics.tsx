import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { motion } from 'framer-motion';
import Scene3D from '../components/Scene3D';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const content = {
  id: {
    title: 'Karakteristik Pencemaran Air',
    description: 'Pencemaran air memiliki berbagai karakteristik yang dapat diidentifikasi melalui parameter fisik, kimia, dan biologis.',
    sections: [
      {
        title: 'Parameter Fisik',
        content: 'Karakteristik fisik meliputi perubahan warna, kekeruhan, suhu, bau, dan rasa air. Air yang tercemar sering memiliki warna keruh, berbau tidak sedap, dan memiliki suhu yang tidak normal.'
      },
      {
        title: 'Parameter Kimia',
        content: 'Parameter kimia mencakup pH, oksigen terlarut (DO), BOD, COD, dan kandungan logam berat. Pencemaran air dapat mengubah keseimbangan kimia air secara signifikan.'
      },
      {
        title: 'Parameter Biologis',
        content: 'Keberadaan mikroorganisme patogen dan perubahan populasi mikroba menjadi indikator pencemaran biologis. Bakteri coliform sering digunakan sebagai indikator utama.'
      }
    ],
    chartTitle: 'Trend Kualitas Air Sungai di Jakarta (2020-2024)',
    chartData: [
      { year: '2020', bod: 45, cod: 85, do: 2.5 },
      { year: '2021', bod: 42, cod: 80, do: 2.8 },
      { year: '2022', bod: 40, cod: 75, do: 3.0 },
      { year: '2023', bod: 38, cod: 72, do: 3.2 },
      { year: '2024', bod: 35, cod: 70, do: 3.5 }
    ]
  },
  en: {
    title: 'Characteristics of Water Pollution',
    description: 'Water pollution has various characteristics that can be identified through physical, chemical, and biological parameters.',
    sections: [
      {
        title: 'Physical Parameters',
        content: 'Physical characteristics include changes in color, turbidity, temperature, odor, and taste of water. Polluted water often has a turbid color, unpleasant odor, and abnormal temperature.'
      },
      {
        title: 'Chemical Parameters',
        content: 'Chemical parameters include pH, dissolved oxygen (DO), BOD, COD, and heavy metal content. Water pollution can significantly alter the chemical balance of water.'
      },
      {
        title: 'Biological Parameters',
        content: 'The presence of pathogenic microorganisms and changes in microbial populations are indicators of biological pollution. Coliform bacteria are often used as the main indicator.'
      }
    ],
    chartTitle: 'River Water Quality Trends in Jakarta (2020-2024)',
    chartData: [
      { year: '2020', bod: 45, cod: 85, do: 2.5 },
      { year: '2021', bod: 42, cod: 80, do: 2.8 },
      { year: '2022', bod: 40, cod: 75, do: 3.0 },
      { year: '2023', bod: 38, cod: 72, do: 3.2 },
      { year: '2024', bod: 35, cod: 70, do: 3.5 }
    ]
  }
};

export default function Characteristics() {
  const { language } = useLanguage();
  const text = content[language];

  return (
    <div className="min-h-screen py-16">
      <div className="section-container">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="page-title"
        >
          {text.title}
        </motion.h1>

        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-white text-lg"
            >
              {text.description}
            </motion.p>

            {text.sections.map((section, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
                className="card"
              >
                <h2 className="text-2xl font-bold mb-4 text-blue-300">
                  {section.title}
                </h2>
                <p className="text-lg leading-relaxed">
                  {section.content}
                </p>
              </motion.div>
            ))}

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="card"
            >
              <h3 className="text-xl font-bold mb-4 text-blue-300">{text.chartTitle}</h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={text.chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="bod" stroke="#60A5FA" name="BOD (mg/L)" />
                    <Line type="monotone" dataKey="cod" stroke="#34D399" name="COD (mg/L)" />
                    <Line type="monotone" dataKey="do" stroke="#F472B6" name="DO (mg/L)" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            className="sticky top-24"
          >
            <Scene3D />
          </motion.div>
        </div>
      </div>
    </div>
  );
}