import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { motion } from 'framer-motion';
import Slider from 'react-slick';
import Scene3D from '../components/Scene3D';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const content = {
  id: {
    title: 'Pencemaran Air di Indonesia',
    subtitle: 'Krisis Lingkungan yang Mengancam',
    description: 'Pencemaran air telah menjadi masalah serius yang mengancam kesehatan masyarakat dan ekosistem Indonesia. Mari pelajari lebih lanjut tentang penyebab, dampak, dan solusinya.',
    cta: 'Pelajari Lebih Lanjut',
    stats: [
      { value: '82%', label: 'Sungai tercemar' },
      { value: '75%', label: 'Air tanah tidak layak minum' },
      { value: '60%', label: 'Penduduk tidak akses air bersih' }
    ]
  },
  en: {
    title: 'Water Pollution in Indonesia',
    subtitle: 'An Environmental Crisis',
    description: 'Water pollution has become a serious issue threatening public health and ecosystems in Indonesia. Let\'s learn more about its causes, impacts, and solutions.',
    cta: 'Learn More',
    stats: [
      { value: '82%', label: 'Polluted rivers' },
      { value: '75%', label: 'Undrinkable groundwater' },
      { value: '60%', label: 'No access to clean water' }
    ]
  }
};

const carouselImages = [
  'https://images.unsplash.com/photo-1621451537084-482c73073a0f?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1636197454063-490169f0a757?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1574752338465-1e3caa0eeb2d?auto=format&fit=crop&w=1200&q=80'
];

export default function Home() {
  const { language } = useLanguage();
  const text = content[language];

  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
  };

  return (
    <div className="min-h-screen">
      <section className="relative h-screen">
        <Slider {...sliderSettings} className="h-screen">
          {carouselImages.map((img, index) => (
            <div key={index} className="h-screen">
              <div
                className="h-screen bg-cover bg-center"
                style={{
                  backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(${img})`
                }}
              />
            </div>
          ))}
        </Slider>

        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white p-8">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl md:text-6xl font-bold mb-4"
            >
              {text.title}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl md:text-2xl mb-8"
            >
              {text.subtitle}
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Link
                to="/definisi"
                className="inline-flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors"
              >
                <span>{text.cta}</span>
                <ArrowRight size={20} />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section-container">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="card">
            <p className="text-lg mb-8">{text.description}</p>
            <div className="grid grid-cols-3 gap-4">
              {text.stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.2 }}
                  className="text-center"
                >
                  <div className="text-3xl font-bold text-blue-400">{stat.value}</div>
                  <div className="text-sm text-blue-200">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
          <Scene3D />
        </div>
      </section>
    </div>
  );
}