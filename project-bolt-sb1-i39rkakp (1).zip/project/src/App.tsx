import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { LanguageProvider } from './context/LanguageContext';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Definition from './pages/Definition';
import Causes from './pages/Causes';
import Impacts from './pages/Impacts';
import Characteristics from './pages/Characteristics';

function App() {
  return (
    <LanguageProvider>
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-700">
          <Navbar />
          <div className="pt-16">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/definisi" element={<Definition />} />
              <Route path="/penyebab" element={<Causes />} />
              <Route path="/dampak" element={<Impacts />} />
              <Route path="/karakteristik" element={<Characteristics />} />
            </Routes>
          </div>
        </div>
      </Router>
    </LanguageProvider>
  );
}

export default App;