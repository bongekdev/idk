# Metasploit-like Shell Framework

A Python-based command-line interface framework inspired by the Metasploit Framework, designed to serve as a template for creating your own custom tools and modules.

## Features

- Command-line interface with Metasploit-like prompt
- Module/tool loading system with dynamic discovery
- Command handling for standard operations (use, set, show, run, back, exit)
- Tool integration framework for easy addition of custom tools
- Tab completion for commands and parameters
- Command history
- Color-coded output

## Installation

1. Clone the repository:
```
git clone https://github.com/yourusername/msf-shell.git
cd msf-shell
```

2. Install required dependencies:
```
pip install -r requirements.txt
```

## Usage

Start the shell:
```
python shell.py
```

### Basic Commands

- `help` - Display help menu
- `use <module>` - Select a module to use
- `show modules` - Show available modules
- `show options` - Show current module options
- `set <option> <value>` - Set an option for the current module
- `run` - Run the current module with set options
- `back` - Move back from the current context
- `exit` - Exit the console
- `add_tool` - Add a new tool to the framework

## Adding Custom Tools

### Interactive Method

1. Use the built-in wizard:
```
msf > add_tool
```

2. Follow the prompts to provide tool information and options.

### Script Method

You can programmatically add tools by creating a Python script and importing the `ToolLoader` class:

```python
from core.tool_loader import ToolLoader

loader = ToolLoader()
loader.add_tool_from_script(
    path="/path/to/your/script.py",
    options={
        "TARGET": {
            "required": True,
            "default": None,
            "description": "Target to attack"
        },
        "PORT": {
            "required": False,
            "default": "80",
            "description": "Target port"
        }
    },
    name="MyTool",
    category="scanner",
    description="My custom scanning tool",
    author="Your Name",
    version="1.0"
)
```

## Creating Modules

Modules are stored in the `modules/` directory and organized by category. Each module should follow the template structure provided in `templates/module_template.py`.

## License

This project is open source and available under the MIT License.