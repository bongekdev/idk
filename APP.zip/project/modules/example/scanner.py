#!/usr/bin/env python3
# Example scanner module

MODULE_INFO = {
    'name': 'scanner',
    'description': 'Example port scanner module',
    'author': 'MSF Shell',
    'version': '1.0',
    'category': 'scanner'
}

import socket
import time
from termcolor import colored

class Module:
    def __init__(self):
        self.name = None
        self.info = None
        self.options = {
            'TARGET': {
                'value': None,
                'required': True,
                'description': 'Target hostname or IP address'
            },
            'PORTS': {
                'value': '80,443,8080',
                'required': True,
                'description': 'Comma-separated list of ports to scan'
            },
            'TIMEOUT': {
                'value': '1',
                'required': False,
                'description': 'Connection timeout in seconds'
            }
        }
    
    def set_option(self, option, value):
        """Set a module option"""
        if option in self.options:
            self.options[option]['value'] = value
            print(colored(f"[*] {option} => {value}", 'green'))
        else:
            print(colored(f"[-] Unknown option: {option}", 'red'))
    
    def show_options(self):
        """Show module options"""
        print(colored(f"\nModule: {self.name}", 'cyan'))
        print("=" * 60)
        print(f"{colored('Name'.ljust(15), 'green')} {colored('Required'.ljust(10), 'green')} {colored('Value'.ljust(15), 'green')} {colored('Description', 'green')}")
        print("-" * 60)
        
        for name, option in self.options.items():
            required = "yes" if option.get('required', False) else "no"
            value = option.get('value', "")
            description = option.get('description', "")
            
            print(f"{colored(name.ljust(15), 'yellow')} {required.ljust(10)} {str(value).ljust(15)} {description}")
        
        print()
    
    def validate_options(self):
        """Validate that all required options are set"""
        for name, option in self.options.items():
            if option.get('required', False) and not option.get('value'):
                print(colored(f"[-] Required option '{name}' is not set", 'red'))
                return False
        return True
    
    def run(self):
        """Run the module"""
        if not self.validate_options():
            return
        
        print(colored(f"[*] Running module: {self.name}", 'green'))
        
        # Parse options
        target = self.options['TARGET']['value']
        ports = [int(p.strip()) for p in self.options['PORTS']['value'].split(',')]
        timeout = float(self.options['TIMEOUT']['value'])
        
        print(colored(f"[*] Starting port scan on {target}", 'green'))
        print(colored(f"[*] Scanning {len(ports)} ports with timeout {timeout}s", 'green'))
        
        open_ports = []
        start_time = time.time()
        
        for port in ports:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            
            try:
                result = sock.connect_ex((target, port))
                if result == 0:
                    service = self._get_service_name(port)
                    open_ports.append((port, service))
                    print(colored(f"[+] Port {port} ({service}): Open", 'green'))
                else:
                    print(colored(f"[-] Port {port}: Closed", 'red'))
            except socket.gaierror:
                print(colored(f"[-] Hostname could not be resolved: {target}", 'red'))
                break
            except socket.error:
                print(colored(f"[-] Could not connect to server: {target}", 'red'))
                break
            finally:
                sock.close()
        
        scan_time = time.time() - start_time
        
        print(colored(f"\n[*] Scan completed in {scan_time:.2f} seconds", 'yellow'))
        if open_ports:
            print(colored("\nOpen Ports Summary:", 'green'))
            print("=" * 40)
            for port, service in open_ports:
                print(colored(f"Port {port} ({service}): Open", 'green'))
        else:
            print(colored("\n[-] No open ports found", 'red'))
    
    def _get_service_name(self, port):
        """Get service name for well-known ports"""
        common_ports = {
            21: 'FTP',
            22: 'SSH',
            23: 'Telnet',
            25: 'SMTP',
            53: 'DNS',
            80: 'HTTP',
            110: 'POP3',
            143: 'IMAP',
            443: 'HTTPS',
            465: 'SMTPS',
            587: 'SMTP',
            993: 'IMAPS',
            995: 'POP3S',
            3306: 'MySQL',
            3389: 'RDP',
            5432: 'PostgreSQL',
            8080: 'HTTP-Proxy',
            8443: 'HTTPS-Alt'
        }
        
        return common_ports.get(port, 'Unknown')