#!/usr/bin/env python3
# Tool loader for adding custom tools to the framework

import os
import json
import shutil
from pathlib import Path
from colorama import Fore, Style

class ToolLoader:
    """Loader for adding new tools to the framework"""
    
    def __init__(self):
        self.template_path = Path("templates")
        self.modules_path = Path("modules")
        
        # Ensure template and modules directories exist
        self.template_path.mkdir(exist_ok=True)
        self.modules_path.mkdir(exist_ok=True)
        
        # Ensure template files exist
        self.create_template_files()
    
    def create_template_files(self):
        """Create template files if they don't exist"""
        template_file = self.template_path / "module_template.py"
        
        if not template_file.exists():
            with open(template_file, 'w') as f:
                f.write('''#!/usr/bin/env python3
# Module template for custom tools

MODULE_INFO = {
    'name': 'template',
    'description': 'Description of the module',
    'author': 'Your Name',
    'version': '1.0',
    'category': 'utility'
}

class Module:
    def __init__(self):
        self.name = None
        self.info = None
        self.options = {
            'TARGET': {
                'value': None,
                'required': True,
                'description': 'Target to run the module against'
            },
            'PORT': {
                'value': '80',
                'required': False,
                'description': 'Target port'
            }
        }
    
    def set_option(self, option, value):
        """Set a module option"""
        if option in self.options:
            self.options[option]['value'] = value
            print(f"{Fore.GREEN}[*] {option} => {value}{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}[-] Unknown option: {option}{Style.RESET_ALL}")
    
    def show_options(self):
        """Show module options"""
        print(f"\n{Fore.CYAN}Module: {self.name}{Style.RESET_ALL}")
        print("=" * 60)
        print(f"{Fore.GREEN}{'Name'.ljust(15)} {'Required'.ljust(10)} {'Value'.ljust(15)} Description{Style.RESET_ALL}")
        print("-" * 60)
        
        for name, option in self.options.items():
            required = "yes" if option.get('required', False) else "no"
            value = option.get('value', "")
            description = option.get('description', "")
            
            print(f"{Fore.YELLOW}{name.ljust(15)}{Style.RESET_ALL} {required.ljust(10)} {str(value).ljust(15)} {description}")
        
        print()
    
    def validate_options(self):
        """Validate that all required options are set"""
        for name, option in self.options.items():
            if option.get('required', False) and not option.get('value'):
                print(f"{Fore.RED}[-] Required option '{name}' is not set{Style.RESET_ALL}")
                return False
        return True
    
    def run(self):
        """Run the module"""
        if not self.validate_options():
            return
        
        print(f"{Fore.GREEN}[*] Running module: {self.name}{Style.RESET_ALL}")
        print(f"{Fore.GREEN}[*] Options: {self.options}{Style.RESET_ALL}")
        
        # Implement your tool logic here
        print(f"{Fore.YELLOW}[*] This is a template module. Replace this with your actual implementation.{Style.RESET_ALL}")
        
        # Example output
        target = self.options['TARGET']['value']
        port = self.options['PORT']['value']
        print(f"{Fore.GREEN}[*] Would execute against {target}:{port}{Style.RESET_ALL}")
''')
            print(f"{Fore.GREEN}[+] Created module template file{Style.RESET_ALL}")
    
    def interactive_add_tool(self):
        """Interactively add a new tool to the framework"""
        print(f"\n{Fore.GREEN}Add New Tool Wizard{Style.RESET_ALL}")
        print("=" * 60)
        
        # Get tool information
        category = input("Category (e.g., scanner, exploit, utility): ").strip() or "uncategorized"
        name = input("Tool name: ").strip()
        
        if not name:
            print(f"{Fore.RED}[-] Tool name is required{Style.RESET_ALL}")
            return
        
        description = input("Description: ").strip() or f"{name} module"
        author = input("Author: ").strip() or "Anonymous"
        version = input("Version: ").strip() or "1.0"
        
        # Create options dictionary
        options = {}
        print("\nAdd options (leave option name empty to finish):")
        
        while True:
            option_name = input("\nOption name (uppercase, leave empty to finish): ").strip().upper()
            if not option_name:
                break
                
            option_required = input("Required (y/n): ").strip().lower() == 'y'
            option_default = input("Default value (leave empty for none): ").strip()
            option_desc = input("Description: ").strip() or f"{option_name} parameter"
            
            options[option_name] = {
                'value': option_default if option_default else None,
                'required': option_required,
                'description': option_desc
            }
        
        # Create module directory
        module_dir = self.modules_path / category
        module_dir.mkdir(exist_ok=True)
        
        # Create module file
        module_file = module_dir / f"{name.lower().replace(' ', '_')}.py"
        
        if module_file.exists():
            overwrite = input(f"\nModule file {module_file} already exists. Overwrite? (y/n): ").strip().lower() == 'y'
            if not overwrite:
                print(f"{Fore.RED}[-] Tool creation cancelled{Style.RESET_ALL}")
                return
        
        # Write module file using template
        with open(self.template_path / "module_template.py", 'r') as template:
            template_content = template.read()
        
        # Replace template values
        module_content = template_content.replace(
            "MODULE_INFO = {",
            f"MODULE_INFO = {{\n    'name': '{name.lower().replace(' ', '_')}',\n    'description': '{description}',\n    'author': '{author}',\n    'version': '{version}',\n    'category': '{category}'"
        ).replace(
            "self.options = {",
            f"self.options = {json.dumps(options, indent=4)}"
        )
        
        # Write module file
        with open(module_file, 'w') as f:
            f.write(module_content)
        
        print(f"\n{Fore.GREEN}[+] Successfully created tool: {category}/{name.lower().replace(' ', '_')}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}[*] File created: {module_file}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}[*] You can now use this module with: use {category}/{name.lower().replace(' ', '_')}{Style.RESET_ALL}")
    
    def add_tool_from_script(self, path, options, name=None, category=None, description=None, author=None, version=None):
        """Add a tool from a script file"""
        if not Path(path).exists():
            print(f"{Fore.RED}[-] Script file not found: {path}{Style.RESET_ALL}")
            return False
            
        if not name:
            name = Path(path).stem
            
        if not category:
            category = "uncategorized"
            
        if not description:
            description = f"{name} module"
            
        if not author:
            author = "Anonymous"
            
        if not version:
            version = "1.0"
        
        # Create module directory
        module_dir = self.modules_path / category
        module_dir.mkdir(exist_ok=True)
        
        # Create module file
        module_file = module_dir / f"{name.lower().replace(' ', '_')}.py"
        
        if module_file.exists():
            print(f"{Fore.RED}[-] Module file already exists: {module_file}{Style.RESET_ALL}")
            return False
            
        # Process options
        processed_options = {}
        for option_name, option_data in options.items():
            required = option_data.get('required', False)
            default = option_data.get('default', None)
            desc = option_data.get('description', f"{option_name} parameter")
            
            processed_options[option_name.upper()] = {
                'value': default,
                'required': required,
                'description': desc
            }
            
        # Write module file using template
        with open(self.template_path / "module_template.py", 'r') as template:
            template_content = template.read()
            
        # Replace template values
        module_content = template_content.replace(
            "MODULE_INFO = {",
            f"MODULE_INFO = {{\n    'name': '{name.lower().replace(' ', '_')}',\n    'description': '{description}',\n    'author': '{author}',\n    'version': '{version}',\n    'category': '{category}'"
        ).replace(
            "self.options = {",
            f"self.options = {json.dumps(processed_options, indent=4)}"
        )
        
        # Copy the actual implementation from the script
        with open(path, 'r') as script:
            script_content = script.read()
            
        # Extract the actual tool logic and add it to the module
        module_content = module_content.replace(
            "# Implement your tool logic here",
            "# Tool implementation\n        " + script_content.replace("\n", "\n        ")
        )
        
        # Write module file
        with open(module_file, 'w') as f:
            f.write(module_content)
            
        print(f"{Fore.GREEN}[+] Successfully added tool from script: {category}/{name.lower().replace(' ', '_')}{Style.RESET_ALL}")
        return True