#!/usr/bin/env python3
# Main shell script for Metasploit-like framework

import os
import sys
import cmd
import importlib.util
import json
from pathlib import Path
from colorama import init, Fore, Back, Style
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import WordCompleter, NestedCompleter

from core.module_manager import ModuleManager
from core.command_handler import CommandHandler
from core.tool_loader import ToolLoader

# Initialize colorama
init()

class MetasploitLikeShell(cmd.Cmd):
    """Main shell class for the Metasploit-like framework"""
    
    def __init__(self):
        super().__init__()
        self.module_manager = ModuleManager()
        self.command_handler = CommandHandler(self)
        self.tool_loader = ToolLoader()
        
        self.current_module = None
        self.options = {}
        
        # Set up prompt session with nested completion
        self.session = PromptSession()
        self.update_completer()
        
        # Load available modules
        self.load_modules()
        
        # Set prompt
        self.update_prompt()
    
    def update_completer(self):
        """Update command completer with current context"""
        completer_dict = {
            'help': None,
            'use': WordCompleter(list(self.module_manager.modules.keys())),
            'show': WordCompleter(['modules', 'options']),
            'set': WordCompleter(list(self.current_module.options.keys()) if self.current_module else []),
            'run': None,
            'back': None,
            'exit': None,
            'add_tool': None
        }
        self.completer = NestedCompleter.from_nested_dict(completer_dict)
    
    def update_prompt(self):
        """Update the command prompt based on current context"""
        if self.current_module:
            self.prompt = f"{Fore.RED}msf ({self.current_module.name}){Style.RESET_ALL} > "
        else:
            self.prompt = f"{Fore.BLUE}msf{Style.RESET_ALL} > "
    
    def load_modules(self):
        """Load all available modules"""
        modules_dir = Path("modules")
        if not modules_dir.exists():
            modules_dir.mkdir(parents=True)
            print(f"{Fore.YELLOW}[*] Created modules directory{Style.RESET_ALL}")
        
        self.module_manager.discover_modules()
        print(f"{Fore.GREEN}[*] Loaded {len(self.module_manager.modules)} modules{Style.RESET_ALL}")
        self.update_completer()
    
    def cmdloop(self):
        """Override cmdloop to use prompt_toolkit"""
        while True:
            try:
                user_input = self.session.prompt(self.prompt, completer=self.completer)
                if user_input == "exit":
                    break
                self.onecmd(user_input)
            except KeyboardInterrupt:
                print("\n")
                continue
            except EOFError:
                break
    
    def emptyline(self):
        """Do nothing on empty line"""
        pass
    
    def default(self, line):
        """Handle unknown commands"""
        print(f"{Fore.RED}[-] Unknown command: {line}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}Type 'help' for a list of available commands{Style.RESET_ALL}")
    
    def do_exit(self, arg):
        """Exit the shell"""
        print(f"{Fore.YELLOW}[*] Exiting...{Style.RESET_ALL}")
        return True
    
    def do_quit(self, arg):
        """Alias for exit"""
        return self.do_exit(arg)
    
    def do_help(self, arg):
        """Show help information"""
        if arg:
            self.command_handler.handle_help(arg)
        else:
            print(f"\n{Fore.GREEN}Core Commands:{Style.RESET_ALL}")
            print("=" * 60)
            cmd_list = [
                ("help [command]", "Display this help menu or command-specific help"),
                ("use <module>", "Select a module to use"),
                ("show modules", "List all available modules"),
                ("show options", "Display module options"),
                ("set <option> <value>", "Set a module option"),
                ("run", "Execute the selected module"),
                ("back", "Return to main menu"),
                ("exit", "Exit the console"),
                ("add_tool", "Add a new tool interactively")
            ]
            
            for cmd, desc in cmd_list:
                print(f"{Fore.CYAN}{cmd.ljust(25)}{Style.RESET_ALL} {desc}")
            print()
    
    def do_use(self, arg):
        """Select a module to use"""
        if not arg:
            print(f"{Fore.RED}[-] Usage: use <module>{Style.RESET_ALL}")
            return
        
        module = self.module_manager.get_module(arg)
        if module:
            self.current_module = module
            self.options = module.options.copy()
            self.update_prompt()
            self.update_completer()
            print(f"{Fore.GREEN}[*] Using module: {module.name}{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}[-] Module '{arg}' not found{Style.RESET_ALL}")
    
    def do_show(self, arg):
        """Show various framework information"""
        if arg == "modules":
            self.module_manager.list_modules()
        elif arg == "options":
            if self.current_module:
                self.current_module.show_options()
            else:
                print(f"{Fore.RED}[-] No module selected{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}[-] Usage: show <modules|options>{Style.RESET_ALL}")
    
    def do_set(self, arg):
        """Set a module option"""
        if not self.current_module:
            print(f"{Fore.RED}[-] No module selected{Style.RESET_ALL}")
            return
            
        args = arg.split(maxsplit=1)
        if len(args) < 2:
            print(f"{Fore.RED}[-] Usage: set <option> <value>{Style.RESET_ALL}")
            return
            
        option, value = args
        self.current_module.set_option(option, value)
    
    def do_run(self, arg):
        """Run the selected module"""
        if not self.current_module:
            print(f"{Fore.RED}[-] No module selected{Style.RESET_ALL}")
            return
            
        self.current_module.run()
    
    def do_back(self, arg):
        """Move back from the current context"""
        if self.current_module:
            self.current_module = None
            self.options = {}
            self.update_prompt()
            self.update_completer()
            print(f"{Fore.YELLOW}[*] Returned to main context{Style.RESET_ALL}")
    
    def do_add_tool(self, arg):
        """Add a new tool to the framework"""
        self.tool_loader.interactive_add_tool()
        # Reload modules after adding a new tool
        self.load_modules()

def main():
    """Main function to start the shell"""
    shell = MetasploitLikeShell()
    
    try:
        shell.cmdloop()
    except KeyboardInterrupt:
        print("\n[*] Interrupted, exiting...")
    except Exception as e:
        print(f"{Fore.RED}[-] Error: {str(e)}{Style.RESET_ALL}")
        sys.exit(1)

if __name__ == "__main__":
    main()