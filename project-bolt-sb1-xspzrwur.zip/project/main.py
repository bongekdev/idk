#!/usr/bin/env python3
"""
NeuroBot - AI Chatbot powered by Neural Networks
Built with Python, featuring backpropagation training and sigmoid activation
"""

import os
import sys
from chat_bot import ChatBot

def print_banner():
    """Print a cool ASCII banner"""
    banner = """
    ███╗   ██╗███████╗██╗   ██╗██████╗  ██████╗ ██████╗  ██████╗ ████████╗
    ████╗  ██║██╔════╝██║   ██║██╔══██╗██╔═══██╗██╔══██╗██╔═══██╗╚══██╔══╝
    ██╔██╗ ██║█████╗  ██║   ██║██████╔╝██║   ██║██████╔╝██║   ██║   ██║   
    ██║╚██╗██║██╔══╝  ██║   ██║██╔══██╗██║   ██║██╔══██╗██║   ██║   ██║   
    ██║ ╚████║███████╗╚██████╔╝██║  ██║╚██████╔╝██████╔╝╚██████╔╝   ██║   
    ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝   
    
    🧠 Neural Network Powered AI Chatbot 🧠
    Features: Backpropagation, Sigmoid Activation, Multiple Layers with Biases
    """
    print(banner)

def main():
    print_banner()
    
    # Create chatbot instance
    chatbot = ChatBot()
    
    # Check if a trained model exists
    model_file = "chatbot_model.json"
    
    print("\n🤖 Welcome to NeuroBot Setup!")
    print("=" * 40)
    
    if os.path.exists(model_file):
        print(f"📁 Found existing model: {model_file}")
        choice = input("Would you like to (L)oad existing model or (T)rain new model? [L/T]: ").strip().upper()
        
        if choice == 'L':
            print("📤 Loading existing model...")
            chatbot.load_model(model_file)
            if chatbot.is_trained:
                print("✅ Model loaded successfully!")
            else:
                print("❌ Failed to load model. Will train a new one.")
                train_new_model(chatbot, model_file)
        else:
            train_new_model(chatbot, model_file)
    else:
        print("📁 No existing model found. Training new model...")
        train_new_model(chatbot, model_file)
    
    # Start chatting
    if chatbot.is_trained:
        chatbot.chat_loop()
    else:
        print("❌ Could not initialize the bot. Please try again.")

def train_new_model(chatbot, model_file):
    """Train a new model with user preferences"""
    print("\n🎯 Training Configuration")
    print("=" * 30)
    
    try:
        # Get training parameters from user
        print("⚙️  Let's configure the neural network training:")
        
        epochs = input("Number of training epochs (default: 1000): ").strip()
        epochs = int(epochs) if epochs else 1000
        
        learning_rate = input("Learning rate (default: 0.1): ").strip()
        learning_rate = float(learning_rate) if learning_rate else 0.1
        
        hidden_size = input("Hidden layer size (default: 64): ").strip()
        hidden_size = int(hidden_size) if hidden_size else 64
        
        print(f"\n🚀 Starting training with:")
        print(f"   • Epochs: {epochs}")
        print(f"   • Learning Rate: {learning_rate}")
        print(f"   • Hidden Size: {hidden_size}")
        
        # Train the model
        losses = chatbot.train_bot(epochs=epochs, learning_rate=learning_rate, hidden_size=hidden_size)
        
        # Save the trained model
        print(f"\n💾 Saving model to {model_file}...")
        chatbot.save_model(model_file)
        
        print("✅ Training completed successfully!")
        
    except ValueError:
        print("⚠️  Invalid input. Using default parameters...")
        chatbot.train_bot()
        chatbot.save_model(model_file)
    except KeyboardInterrupt:
        print("\n⚠️  Training interrupted by user.")
        return
    except Exception as e:
        print(f"❌ Training error: {e}")
        return

def show_help():
    """Show help information"""
    help_text = """
    NeuroBot - Neural Network AI Chatbot
    
    🧠 Technical Features:
    • Multi-layer neural network with sigmoid activation
    • Backpropagation training algorithm
    • Bias layers for improved learning
    • Text preprocessing and vectorization
    • Customizable training parameters
    
    💬 Chat Features:
    • Casual conversation capabilities
    • Context-aware responses
    • Personality-driven interactions
    • Fallback responses for unknown inputs
    
    🎛️  Commands:
    • Type naturally to chat with the bot
    • Use 'quit', 'exit', or 'bye' to end conversation
    • The bot learns from predefined conversation patterns
    
    🔧 Customization:
    • Adjust epochs, learning rate, and hidden layer size
    • Training data can be expanded in training_data.py
    • Model automatically saves and loads for persistence
    """
    print(help_text)

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ['--help', '-h', 'help']:
        show_help()
    else:
        main()