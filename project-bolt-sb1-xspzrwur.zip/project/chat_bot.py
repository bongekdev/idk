import numpy as np
import random
from neural_network import NeuralNetwork
from text_processor import TextProcessor
from training_data import TrainingData

class ChatBot:
    def __init__(self):
        self.neural_network = None
        self.text_processor = TextProcessor()
        self.training_data = TrainingData()
        self.response_to_index = {}
        self.index_to_response = {}
        self.num_responses = 0
        self.max_length = 20
        self.is_trained = False
        
    def train_bot(self, epochs=1000, learning_rate=0.1, hidden_size=64):
        """Train the chatbot neural network"""
        print("🧠 Starting neural network training...")
        print("=" * 50)
        
        # Get training data
        input_vectors, response_vectors, response_to_index, index_to_response, num_responses = \
            self.training_data.get_training_data(self.text_processor, self.max_length)
        
        # Store response mappings
        self.response_to_index = response_to_index
        self.index_to_response = index_to_response
        self.num_responses = num_responses
        
        print(f"📊 Training data: {len(input_vectors)} examples")
        print(f"🎯 Possible responses: {num_responses}")
        print(f"📝 Vocabulary size: {self.text_processor.vocab_size}")
        print(f"🔧 Hidden layer size: {hidden_size}")
        print(f"📈 Learning rate: {learning_rate}")
        print(f"🔄 Training epochs: {epochs}")
        print("=" * 50)
        
        # Create neural network
        input_size = self.max_length
        self.neural_network = NeuralNetwork(
            input_size=input_size,
            hidden_size=hidden_size,
            output_size=num_responses,
            learning_rate=learning_rate
        )
        
        # Train the network
        losses = self.neural_network.train(input_vectors, response_vectors, epochs)
        
        self.is_trained = True
        print("\n🎉 Training completed!")
        print(f"Final loss: {losses[-1]:.6f}")
        print("=" * 50)
        
        return losses
    
    def get_response(self, user_input):
        """Get AI response for user input"""
        if not self.is_trained:
            return "I need to be trained first! Please run the training process."
        
        # Convert user input to vector
        input_vector = self.text_processor.text_to_vector(user_input, self.max_length)
        input_vector = input_vector.reshape(1, -1)  # Reshape for prediction
        
        # Get neural network prediction
        prediction = self.neural_network.predict(input_vector)
        
        # Get the most likely response
        response_index = np.argmax(prediction[0])
        
        # Add some randomness to make conversations more interesting
        top_indices = np.argsort(prediction[0])[-3:]  # Get top 3 predictions
        
        # Sometimes pick randomly from top responses
        if random.random() < 0.3:  # 30% chance of random selection
            response_index = random.choice(top_indices)
        
        if response_index in self.index_to_response:
            return self.index_to_response[response_index]
        else:
            # Fallback responses
            fallback_responses = [
                "That's interesting! Tell me more.",
                "I see! What else would you like to talk about?",
                "Cool! I'd love to learn more about that.",
                "That sounds fascinating! Can you elaborate?",
                "Hmm, that's something new for me to think about!",
            ]
            return random.choice(fallback_responses)
    
    def chat_loop(self):
        """Main chat loop"""
        print("\n" + "="*60)
        print("🤖 NeuroBot - AI Chatbot powered by Neural Networks!")
        print("="*60)
        print("💡 Type 'quit', 'exit', or 'bye' to end the conversation")
        print("🧠 I'm powered by backpropagation and sigmoid activation!")
        print("=" * 60)
        
        if not self.is_trained:
            print("⚠️  Bot is not trained yet. Please train first!")
            return
        
        conversation_count = 0
        
        while True:
            try:
                # Get user input
                user_input = input("\n🙋 You: ").strip()
                
                # Check for exit commands
                if user_input.lower() in ['quit', 'exit', 'bye', 'goodbye']:
                    print("🤖 NeuroBot: Goodbye! It was great chatting with you! 👋")
                    break
                
                if user_input == "":
                    print("🤖 NeuroBot: I'm here! Say something to me!")
                    continue
                
                # Get AI response
                response = self.get_response(user_input)
                print(f"🤖 NeuroBot: {response}")
                
                conversation_count += 1
                
                # Add some personality after several exchanges
                if conversation_count % 5 == 0:
                    bonus_responses = [
                        "I'm really enjoying our conversation!",
                        "You're fun to talk to!",
                        "This is great! I love chatting with you!",
                    ]
                    print(f"🤖 NeuroBot: {random.choice(bonus_responses)}")
                
            except KeyboardInterrupt:
                print("\n🤖 NeuroBot: Goodbye! Chat with you later! 👋")
                break
            except Exception as e:
                print(f"🤖 NeuroBot: Oops! Something went wrong: {e}")
                print("🤖 NeuroBot: But I'm still here to chat!")
    
    def save_model(self, filename="chatbot_model.json"):
        """Save the trained model"""
        if self.neural_network:
            self.neural_network.save_model(filename)
    
    def load_model(self, filename="chatbot_model.json"):
        """Load a trained model"""
        try:
            # First need to set up the text processor and mappings
            input_vectors, response_vectors, response_to_index, index_to_response, num_responses = \
                self.training_data.get_training_data(self.text_processor, self.max_length)
            
            self.response_to_index = response_to_index
            self.index_to_response = index_to_response
            self.num_responses = num_responses
            
            # Create neural network with correct dimensions
            self.neural_network = NeuralNetwork(
                input_size=self.max_length,
                hidden_size=64,  # Default hidden size
                output_size=num_responses
            )
            
            # Load the trained weights
            self.neural_network.load_model(filename)
            self.is_trained = True
            
        except FileNotFoundError:
            print(f"Model file {filename} not found. Please train the bot first.")
        except Exception as e:
            print(f"Error loading model: {e}")