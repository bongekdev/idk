import numpy as np
import random

class TrainingData:
    def __init__(self):
        self.conversation_pairs = [
            # Greetings
            ("hello", "Hello! How are you doing today?"),
            ("hi", "Hi there! What's up?"),
            ("hey", "Hey! Nice to meet you!"),
            ("good morning", "Good morning! Hope you have a great day!"),
            ("good evening", "Good evening! How was your day?"),
            ("good night", "Good night! Sweet dreams!"),
            
            # How are you responses
            ("how are you", "I'm doing great! Thanks for asking. How about you?"),
            ("how do you feel", "I feel fantastic! Ready to chat with you!"),
            ("what's up", "Not much, just here chatting! What about you?"),
            
            # Personal questions
            ("what's your name", "I'm an AI chatbot created with neural networks! You can call me NeuroBot."),
            ("who are you", "I'm NeuroBot, a friendly AI that loves to chat!"),
            ("what are you", "I'm an artificial intelligence built with Python and neural networks!"),
            
            # Compliments and responses
            ("you're cool", "Thank you! You're pretty cool yourself!"),
            ("you're smart", "Thanks! I try my best to be helpful and intelligent."),
            ("nice", "Thank you! I appreciate that!"),
            
            # Hobbies and interests
            ("what do you like", "I enjoy chatting with people and learning new things!"),
            ("do you have hobbies", "I love conversations and helping people! What about you?"),
            ("what's your favorite", "I really enjoy good conversations! What's your favorite thing?"),
            
            # Weather and general topics
            ("nice weather", "Yes, it sounds lovely! Are you enjoying it?"),
            ("it's cold", "Stay warm! Maybe some hot chocolate would help?"),
            ("it's hot", "That sounds quite warm! Stay hydrated!"),
            
            # Questions about AI
            ("are you real", "I'm as real as software can be! I'm here and ready to chat."),
            ("are you human", "No, I'm an AI, but I try to be as friendly as a human!"),
            ("can you learn", "Yes! I was trained using neural networks and backpropagation."),
            
            # Emotions and feelings
            ("i'm happy", "That's wonderful! I'm happy to hear you're happy!"),
            ("i'm sad", "I'm sorry to hear that. Want to talk about it?"),
            ("i'm excited", "That's awesome! What's got you so excited?"),
            ("i'm bored", "Let's chat and make things more interesting!"),
            
            # Random fun responses
            ("tell me a joke", "Why don't scientists trust atoms? Because they make up everything!"),
            ("something funny", "I told my computer a joke about UDP... I don't know if it got it!"),
            ("interesting fact", "Did you know that neural networks are inspired by how our brains work?"),
            
            # Goodbyes
            ("bye", "Goodbye! It was great chatting with you!"),
            ("see you later", "See you later! Have a wonderful day!"),
            ("goodbye", "Goodbye! Come back and chat anytime!"),
            ("talk to you later", "Sounds good! Talk to you later!"),
            
            # Default responses for unknown inputs
            ("i don't understand", "That's interesting! Can you tell me more?"),
            ("random input", "I find that fascinating! What else would you like to talk about?"),
            ("unknown", "That's cool! I'd love to learn more about that topic."),
        ]
        
        # Add some variations and expansions
        self.expand_training_data()
    
    def expand_training_data(self):
        """Add variations to make training data more robust"""
        additional_pairs = []
        
        # Add variations with punctuation
        for input_text, response in self.conversation_pairs:
            # Add versions with punctuation
            additional_pairs.append((input_text + "!", response))
            additional_pairs.append((input_text + "?", response))
            additional_pairs.append((input_text + ".", response))
            
            # Add versions with slight modifications
            if len(input_text.split()) > 1:
                words = input_text.split()
                # Shuffle some words for variety
                if len(words) > 2:
                    shuffled = words.copy()
                    random.shuffle(shuffled)
                    additional_pairs.append((" ".join(shuffled), response))
        
        self.conversation_pairs.extend(additional_pairs)
        
        print(f"Training data expanded to {len(self.conversation_pairs)} conversation pairs")
    
    def get_inputs_and_responses(self):
        """Get separate lists of inputs and responses"""
        inputs = [pair[0] for pair in self.conversation_pairs]
        responses = [pair[1] for pair in self.conversation_pairs]
        return inputs, responses
    
    def create_response_mapping(self, responses):
        """Create mapping from responses to indices"""
        unique_responses = list(set(responses))
        response_to_index = {response: i for i, response in enumerate(unique_responses)}
        index_to_response = {i: response for response, i in response_to_index.items()}
        return response_to_index, index_to_response, len(unique_responses)
    
    def responses_to_one_hot(self, responses, response_to_index, num_responses):
        """Convert responses to one-hot encoded vectors"""
        one_hot_responses = np.zeros((len(responses), num_responses))
        for i, response in enumerate(responses):
            if response in response_to_index:
                one_hot_responses[i][response_to_index[response]] = 1
        return one_hot_responses
    
    def get_training_data(self, text_processor, max_length=20):
        """Get processed training data ready for neural network"""
        inputs, responses = self.get_inputs_and_responses()
        
        # Build vocabulary from inputs
        text_processor.build_vocabulary(inputs)
        
        # Convert inputs to vectors
        input_vectors = text_processor.texts_to_vectors(inputs, max_length)
        
        # Create response mapping
        response_to_index, index_to_response, num_responses = self.create_response_mapping(responses)
        
        # Convert responses to one-hot vectors
        response_vectors = self.responses_to_one_hot(responses, response_to_index, num_responses)
        
        return input_vectors, response_vectors, response_to_index, index_to_response, num_responses