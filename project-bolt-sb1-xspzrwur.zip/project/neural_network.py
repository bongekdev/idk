import numpy as np
import json
import random

class NeuralNetwork:
    def __init__(self, input_size, hidden_size, output_size, learning_rate=0.01):
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.learning_rate = learning_rate
        
        # Initialize weights and biases with random values
        # Input to hidden layer
        self.weights_input_hidden = np.random.uniform(-1, 1, (self.input_size, self.hidden_size))
        self.bias_hidden = np.random.uniform(-1, 1, (1, self.hidden_size))
        
        # Hidden to output layer
        self.weights_hidden_output = np.random.uniform(-1, 1, (self.hidden_size, self.output_size))
        self.bias_output = np.random.uniform(-1, 1, (1, self.output_size))
        
        # Additional hidden layer for complexity
        self.weights_hidden_hidden = np.random.uniform(-1, 1, (self.hidden_size, self.hidden_size))
        self.bias_hidden2 = np.random.uniform(-1, 1, (1, self.hidden_size))
        
    def sigmoid(self, x):
        """Sigmoid activation function"""
        # Clip x to prevent overflow
        x = np.clip(x, -500, 500)
        return 1 / (1 + np.exp(-x))
    
    def sigmoid_derivative(self, x):
        """Derivative of sigmoid function"""
        return x * (1 - x)
    
    def forward(self, X):
        """Forward propagation through the network"""
        # Input to first hidden layer
        self.z1 = np.dot(X, self.weights_input_hidden) + self.bias_hidden
        self.a1 = self.sigmoid(self.z1)
        
        # First hidden to second hidden layer
        self.z2 = np.dot(self.a1, self.weights_hidden_hidden) + self.bias_hidden2
        self.a2 = self.sigmoid(self.z2)
        
        # Second hidden to output layer
        self.z3 = np.dot(self.a2, self.weights_hidden_output) + self.bias_output
        self.output = self.sigmoid(self.z3)
        
        return self.output
    
    def backward(self, X, y, output):
        """Backpropagation algorithm"""
        m = X.shape[0]
        
        # Calculate output layer error
        output_error = y - output
        output_delta = output_error * self.sigmoid_derivative(output)
        
        # Calculate second hidden layer error
        hidden2_error = output_delta.dot(self.weights_hidden_output.T)
        hidden2_delta = hidden2_error * self.sigmoid_derivative(self.a2)
        
        # Calculate first hidden layer error
        hidden1_error = hidden2_delta.dot(self.weights_hidden_hidden.T)
        hidden1_delta = hidden1_error * self.sigmoid_derivative(self.a1)
        
        # Update weights and biases
        self.weights_hidden_output += self.a2.T.dot(output_delta) * self.learning_rate
        self.bias_output += np.sum(output_delta, axis=0, keepdims=True) * self.learning_rate
        
        self.weights_hidden_hidden += self.a1.T.dot(hidden2_delta) * self.learning_rate
        self.bias_hidden2 += np.sum(hidden2_delta, axis=0, keepdims=True) * self.learning_rate
        
        self.weights_input_hidden += X.T.dot(hidden1_delta) * self.learning_rate
        self.bias_hidden += np.sum(hidden1_delta, axis=0, keepdims=True) * self.learning_rate
    
    def train(self, X, y, epochs):
        """Train the neural network"""
        losses = []
        for epoch in range(epochs):
            # Forward propagation
            output = self.forward(X)
            
            # Calculate loss (mean squared error)
            loss = np.mean(np.square(y - output))
            losses.append(loss)
            
            # Backpropagation
            self.backward(X, y, output)
            
            if epoch % 100 == 0:
                print(f"Epoch {epoch}/{epochs}, Loss: {loss:.6f}")
        
        return losses
    
    def predict(self, X):
        """Make predictions"""
        return self.forward(X)
    
    def save_model(self, filename):
        """Save the trained model"""
        model_data = {
            'weights_input_hidden': self.weights_input_hidden.tolist(),
            'bias_hidden': self.bias_hidden.tolist(),
            'weights_hidden_hidden': self.weights_hidden_hidden.tolist(),
            'bias_hidden2': self.bias_hidden2.tolist(),
            'weights_hidden_output': self.weights_hidden_output.tolist(),
            'bias_output': self.bias_output.tolist(),
            'input_size': self.input_size,
            'hidden_size': self.hidden_size,
            'output_size': self.output_size
        }
        with open(filename, 'w') as f:
            json.dump(model_data, f)
        print(f"Model saved to {filename}")
    
    def load_model(self, filename):
        """Load a trained model"""
        with open(filename, 'r') as f:
            model_data = json.load(f)
        
        self.weights_input_hidden = np.array(model_data['weights_input_hidden'])
        self.bias_hidden = np.array(model_data['bias_hidden'])
        self.weights_hidden_hidden = np.array(model_data['weights_hidden_hidden'])
        self.bias_hidden2 = np.array(model_data['bias_hidden2'])
        self.weights_hidden_output = np.array(model_data['weights_hidden_output'])
        self.bias_output = np.array(model_data['bias_output'])
        
        print(f"Model loaded from {filename}")