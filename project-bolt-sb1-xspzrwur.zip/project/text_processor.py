import re
import numpy as np
from collections import Counter

class TextProcessor:
    def __init__(self):
        self.word_to_index = {}
        self.index_to_word = {}
        self.vocab_size = 0
        
    def preprocess_text(self, text):
        """Clean and preprocess text"""
        # Convert to lowercase
        text = text.lower()
        # Remove special characters except basic punctuation
        text = re.sub(r'[^a-zA-Z0-9\s\.\?\!\,]', '', text)
        # Remove extra whitespace
        text = ' '.join(text.split())
        return text
    
    def build_vocabulary(self, texts):
        """Build vocabulary from training texts"""
        all_words = []
        for text in texts:
            words = self.preprocess_text(text).split()
            all_words.extend(words)
        
        # Count word frequencies
        word_counts = Counter(all_words)
        
        # Create word to index mapping
        unique_words = sorted(word_counts.keys())
        self.word_to_index = {word: i for i, word in enumerate(unique_words)}
        self.index_to_word = {i: word for word, i in self.word_to_index.items()}
        self.vocab_size = len(unique_words)
        
        print(f"Vocabulary built with {self.vocab_size} unique words")
    
    def text_to_vector(self, text, max_length=20):
        """Convert text to numerical vector"""
        words = self.preprocess_text(text).split()
        vector = np.zeros(max_length)
        
        for i, word in enumerate(words[:max_length]):
            if word in self.word_to_index:
                vector[i] = self.word_to_index[word] + 1  # +1 to avoid zero
        
        # Normalize the vector
        if np.sum(vector) > 0:
            vector = vector / np.sum(vector)
        
        return vector
    
    def texts_to_vectors(self, texts, max_length=20):
        """Convert multiple texts to vectors"""
        vectors = []
        for text in texts:
            vectors.append(self.text_to_vector(text, max_length))
        return np.array(vectors)
    
    def vector_to_response_index(self, vector):
        """Convert network output to response index"""
        return np.argmax(vector)
    
    def get_word_similarity(self, word1, word2):
        """Simple word similarity based on character overlap"""
        if word1 == word2:
            return 1.0
        
        common_chars = set(word1.lower()) & set(word2.lower())
        total_chars = set(word1.lower()) | set(word2.lower())
        
        if len(total_chars) == 0:
            return 0.0
        
        return len(common_chars) / len(total_chars)