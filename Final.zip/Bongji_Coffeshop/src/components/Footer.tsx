import React from 'react';
import { MapPin, Phone, Mail, Instagram } from 'lucide-react';
import Loading from "./Loading";

const Footer = () => {
  return (
    <Loading>
    <footer className="bg-brown-900 mt-auto text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Instagram className="h-4 w-4" />
                <span>@ar.ddn</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4" />
                <span>bongerean@gmail.com</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Main Location</h3>
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4" />
              <span>Jl. Basuki Rahmat No.21 - 23, Surabaya (Lil Tiger)</span>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 flex-wrap">Hours</h3>
            <p>Senin - Jumat: 8:00 PM - 1:00 PM</p>
            <p>Saturday - Sunday: 7:00 PM - 2:00 PM</p>
          </div>
        </div>

        <div className="mt-8 pt-4 border-t border-brown-700 text-center">
          <p>
            &copy; {new Date().getFullYear()} Ahmad Ardiansyah Hariadi. All
            rights reserved.
          </p>
        </div>
      </div>
    </footer>
    </Loading>
  );
};

export default Footer;
