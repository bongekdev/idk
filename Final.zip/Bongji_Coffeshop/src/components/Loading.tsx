import { useState, useEffect } from "react";

export default function Loading({ children, loadingDelay = 3000 }) {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), loadingDelay);
    return () => clearTimeout(timer);
  }, [loadingDelay]);

  if (isLoading) {
    return (
    <div className="flex justify-center items-center h-screen bg-white">
      <div className="flex space-x-4">
        <span className="w-6 h-6 bg-brown-900 rounded-full animate-bounce delay-0"></span>
        <span className="w-6 h-6 bg-brown-900 rounded-full animate-bounce delay-500"></span>
        <span className="w-6 h-6 bg-brown-900 rounded-full animate-bounce delay-1500"></span>
      </div>
    </div>
    );
  }

  return <>{children}</>;
}

