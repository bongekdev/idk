import React, { useState, useEffect, useRef } from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const videos = [
  {
    id: 1,
    url: 'https://github.com/bongekdev/idk/raw/refs/heads/main/AQN-_8sVj2Hufl8-xVSOTWSyFz8E6QVWgyg-y3XQOZ_diUunLLDpyHsGaSoIKSqCPXq7iI-8tzas0AmfjsgnHyY2w-S6Yx0QNN9YfvE.mp4',
  },
  {
    id: 2,
    url: 'https://github.com/bongekdev/idk/raw/refs/heads/main/AQN5XyUCk4QNYUxtUQGs4WnLnv_f_jPeM_8BAH3JWG0Y6KihqzKiCflspAHDOcSBRdrIVzCEPaVQLM22PC6PXFlYXbRXZhrb_Xwizqk.mp4',
  },
  {
    id: 3,
    url: 'https://github.com/bongekdev/idk/raw/refs/heads/main/AQP0vhlgvLBmweoTzxprVVigghmlJ4jQj1l_GbrWatq56S610J7w6rZuSBJildWyh5Veb1GsTLaOzcxy2_qEU7XJYB5rvFQ0GDyTxlM.mp4',
  },
];

const VideoItem = ({ videoSrc }) => {
  const videoRef = useRef(null);
  const [isMuted, setIsMuted] = useState(true);

  const handleMouseEnter = () => videoRef.current?.play();
  const handleMouseLeave = () => {
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !videoRef.current.muted;
      setIsMuted(videoRef.current.muted);
    }
  };

  return (
    <div className="relative p-2 bg-white rounded-lg flex justify-center items-center">
      <video
        ref={videoRef}
        src={videoSrc}
        width="100%"
        height="auto"
        preload="metadata"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 rounded-md object-cover cursor-pointer w-[300px] h-[333px] max-w-full"
        muted={isMuted} // Muted default, bisa di-unmute
      />
      <button
        onClick={toggleMute}
        className="absolute bottom-2 right-2 text-white p-1 py-1 text-xs rounded grid grid-cols-1 lg:grid-cols-2 gap-8"
      >
        {isMuted ? '🔇' : '🔊'}
      </button>
    </div>
  );
};

function VideoCarousel() {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const settings = {
    dots: isMobile,
    infinite: true,
    speed: 500,
    slidesToShow: isMobile ? 1 : 3,
    slidesToScroll: 1,
    arrows: false,
    appendDots: (dots) => (
      <div style={{ position: 'absolute', bottom: '-60px' }}>
        <ul style={{ margin: '0px' }}> {dots} </ul>
      </div>
    ),
  };

  return (
    <div className="w-11/12 h-full w-full p-8 mt-8 mx-auto p-4 bg-white shadow-2xl flex-wrap rounded-xl">
      <Slider {...settings}>
        {videos.map((video) => (
          <div key={video.id}>
            <VideoItem videoSrc={video.url} />
          </div>
        ))}
      </Slider>
    </div>
  );
}

export default VideoCarousel;
