import React from 'react';
import { Coffee, Cake, GlassWater } from 'lucide-react';
import { describe } from 'node:test';
import Loading from "../components/Loading";

const products = [
  {
    category: 'Hot Coffee',
    items: [
      {
        name: 'House Blend',
        price: 3.5,
        description: 'Our signature medium roast coffee',
      },
      {
        name: 'Dark Roast',
        price: 3.5,
        description: 'Bold and full-bodied coffee',
      },
      {
        name: 'Espresso',
        price: 2.75,
        description: 'Rich and concentrated shot',
      },
      {
        name: 'Cappuccino',
        price: 4.5,
        description: 'Espresso with steamed milk and foam',
      },
      { name: 'Latte', price: 4.75, description: 'Espresso with steamed milk' },
      { name: 'Long Black', price: 5.25, description: 'Strong Coffee' },
      {
        name: 'Mochaccino',
        price: 4.25,
        description: 'Espresso with more foam',
      },
      {
        name: 'Americano ',
        price: 2.45,
        description: 'Espresso with hot water',
      },
    ],
  },
  {
    category: 'Cold Drinks',
    items: [
      {
        name: 'Iced Coffee',
        price: 3.75,
        description: 'Chilled house blend coffee',
      },
      {
        name: 'Cold Brew',
        price: 4.25,
        description: 'Smooth, slow-steeped coffee',
      },
      {
        name: 'Iced Latte',
        price: 4.95,
        description: 'Chilled espresso with milk',
      },
      { name: 'Frappuccino', price: 5.5, description: 'Blended coffee drink' },
      {
        name: 'Butterscooth',
        price: 7.35,
        description: 'Our Premium Iced Coffee',
      },
      {
        name: 'Sea Salt Caramel',
        price: 6.35,
        description: 'Espresso, Caramel, and Sea salt.',
      },
    ],
  },
  {
    category: 'Cocktails',
    items: [
      {
        name: 'Margarita',
        price: 8.45,
        description:
          'Tequila, lime juice, and orange liqueur, served with a salted rim',
      },
      {
        name: 'Martini',
        price: 11.25,
        description:
          'Gin and dry vermouth, garnished with an olive or lemon twist.',
      },
      {
        name: 'Mojito',
        price: 9.35,
        description:
          'Rum, mint, lime, sugar, and soda water for a fresh, minty flavor.',
      },
      {
        name: 'Old Fashioned',
        price: 12.35,
        description:
          'Whiskey, sugar, bitters, and citrus peel, a simple, strong drink',
      },
      {
        name: 'Negroni',
        price: 13.35,
        description:
          'Equal parts gin, Campari, and sweet vermouth, known for its bitter taste.',
      },
      {
        name: 'Cosmopolitan',
        price: 11.65,
        description:
          'Vodka, triple sec, cranberry juice, and lime, fruity and tart.',
      },
    ],
  },
  {
    category: 'Pastries',
    items: [
      { name: 'Croissant', price: 3.25, description: 'Buttery, flaky pastry' },
      {
        name: 'Muffin',
        price: 2.95,
        description: 'Freshly baked, various flavors',
      },
      { name: 'Scone', price: 3.5, description: 'Traditional British pastry' },
      {
        name: 'Danish',
        price: 3.75,
        description: 'Sweet pastry with fruit filling',
      },
    ],
  },
];

const Products = () => {
  return (
    <Loading>
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h1 className="text-2xl font-bold mb-6">Product Menu</h1>

        <div className="grid gap-8">
          {products.map((category, index) => (
            <div key={index} className="space-y-4">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                {category.category === 'Pastries' ? (
                  <Cake className="h-5 w-5" />
                ) : category.category === 'Cocktails' ? (
                  <GlassWater className="h-5 w-5" />
                ) : (
                  <Coffee className="h-5 w-5" />
                )}
                {category.category}
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {category.items.map((item, itemIndex) => (
                  <div
                    key={itemIndex}
                    className="bg-brown-50 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-lg">{item.name}</h3>
                      <span className="text-brown-800 font-medium">
                        ${item.price.toFixed(2)}
                      </span>
                    </div>
                    <p className="text-gray-600 text-sm">{item.description}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
    </Loading>
  );
};

export default Products;
