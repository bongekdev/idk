import React from 'react';
import { Package, AlertTriangle } from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import Loading from "../components/Loading";

const inventoryData = [
  {
    item: 'Arabica',
    stock: 670,
    unit: 'kg',
    minStock: 200,
    reorderPoint: 250,
  },
  {
    item: 'Robusta',
    stock: 875,
    unit: 'kg',
    minStock: 150,
    reorderPoint: 200,
  },
  { item: 'Milk', stock: 950, unit: 'L', minStock: 400, reorderPoint: 500 },
  { item: 'Sugar', stock: 675, unit: 'kg', minStock: 100, reorderPoint: 150 },
  {
    item: '12oz',
    stock: 500,
    unit: 'Pieces',
    minStock: 200,
    reorderPoint: 250,
  },
  {
    item: '16oz',
    stock: 430,
    unit: 'Pieces',
    minStock: 350,
    reorderPoint: 360,
  },
  {
    item: 'Syrups',
    stock: 180,
    unit: 'Bottles',
    minStock: 80,
    reorderPoint: 200,
  },
  {
    item: 'To-Go Lids',
    stock: 200,
    unit: 'Pieces',
    minStock: 100,
    reorderPoint: 750,
  },
  {
    item: 'SS',
    stock: 450,
    unit: 'Bottles',
    minStock: 150,
    reorderPoint: 75,
  },
  {
    item: 'Vodka',
    stock: 320,
    unit: 'Bottles',
    minStock: 120,
    reorderPoint: 150,
  },
  {
    item: 'Whisky',
    stock: 200,
    unit: 'Bottles',
    minStock: 320,
    reorderPoint: 400,
  },
  {
    item: 'Gin',
    stock: 256,
    unit: 'Bottles',
    minStock: 67,
    reorderPoint: 100,
  },
  {
    item: 'Caramel',
    stock: 322,
    unit: 'Pieces',
    minStock: 200,
    reorderPoint: 240,
  },
];

const cocktailData = [
  {
    item: 'Rum',
    stock: 120,
    unit: 'Bottles',
    minStock: 60,
    reorderPoint: 90,
  },
  {
    item: 'Tequila',
    stock: 80,
    unit: 'Bottles',
    minStock: 30,
    reorderPoint: 60,
  },
  {
    item: 'Triple Sec',
    stock: 70,
    unit: 'Bottles',
    minStock: 20,
    reorderPoint: 50,
  },
  {
    item: 'Lime Juice',
    stock: 200,
    unit: 'ml',
    minStock: 100,
    reorderPoint: 150,
  },
  {
    item: 'Sugar Syrup',
    stock: 300,
    unit: 'ml',
    minStock: 150,
    reorderPoint: 200,
  },
  {
    item: 'Angostura Bitters',
    stock: 50,
    unit: 'ml',
    minStock: 20,
    reorderPoint: 40,
  },
  {
    item: 'Mint Leaves',
    stock: 500,
    unit: 'grams',
    minStock: 200,
    reorderPoint: 350,
  },
];

const stockLevelData = inventoryData.map((item) => ({
  name: item.item,
  current: item.stock,
  minimum: item.minStock,
}));

const cocktailLevelData = cocktailData.map((item) => ({
  name: item.item,
  current: item.stock,
  minimum: item.minStock,
}));

const Inventory = () => {
  const lowStockItems = inventoryData.filter(
    (item) => item.stock <= item.reorderPoint
  );
  const lowStockItemsC = cocktailData.filter(
    (item) => item.stock <= item.reorderPoint
  );

  return (
    <Loading>
    <div className="space-y-8">
      {/* Alert Section */}
      {lowStockItems.length > 0 && (
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 overflow-x-auto">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-yellow-400 mr-2" />
            <p className="text-yellow-700">
              <span className="font-bold">Attention needed!</span>{' '}
              {lowStockItems.length} items perlu pemesanan.
            </p>
          </div>
        </div>
      )}

      {/* Stock Level Chart */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold mb-6">Daftar Stocks</h2>
        <div className="w-full overflow-x-auto">
          <BarChart
            width={800}
            height={400}
            barCategoryGap={15}
            data={stockLevelData}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis
              interval={0}
              dataKey="name"
              angle={0}
              textAnchor="middle"
              height={100}
              tick={{ fontSize: 13 }}
            />
            <YAxis />
            <Tooltip />
            <Bar dataKey="current" fill="#a18072" name="Sisa Stocks" />
            <Bar dataKey="minimum" fill="#d2bab0" name="Minimum Stocks" />
          </BarChart>
        </div>
        <h2 className="text-xl font-semibold mb-6">
          Daftar Stocks (Cocktails)
        </h2>
        <div className="w-full overflow-x-auto">
          <BarChart
            width={800}
            height={400}
            barCategoryGap={15}
            data={cocktailData}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis
              interval={0}
              dataKey="item"
              angle={0}
              textAnchor="middle"
              height={100}
              tick={{ fontSize: 13 }}
            />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="stock" fill="#a18072" name="Sisa Stocks" />
            <Bar dataKey="minStock" fill="#d2bab0" name="Minimum Stocks" />
          </BarChart>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold">Detail Stocks & Supplay</h2>
          <div className="flex items-center space-x-2">
            <Package className="h-5 w-5 text-brown-600" />
            <span className="text-sm text-gray-600">
              Total Items: {inventoryData.length}
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Item
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Sisa Stocks
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Unit
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Minimal Pemesanan
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {inventoryData.map((item, index) => (
                <tr key={index}>
                  <td className="px-6 py-4 whitespace-nowrap">{item.item}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {item.stock.toLocaleString()} {item.unit}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">{item.unit}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        item.stock <= item.minStock
                          ? 'bg-red-100 text-red-800'
                          : item.stock <= item.reorderPoint
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-green-100 text-green-800'
                      }`}
                    >
                      {item.stock <= item.minStock
                        ? 'Critical'
                        : item.stock <= item.reorderPoint
                        ? 'Low'
                        : 'Good'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {item.reorderPoint.toLocaleString()} {item.unit}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
    </Loading>
  );
};

export default Inventory;
