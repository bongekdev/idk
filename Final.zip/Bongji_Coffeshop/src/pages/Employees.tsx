import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import Loading from "../components/Loading";

const employeeData = [
  { position: 'Barista', count: 35, avgSalary: 45 },
  { position: 'Waiters', count: 30, avgSalary: 42 },
  { position: 'Manager', count: 12, avgSalary: 55 },
  { position: 'SEO', count: 4, avgSalary: 75 },
  { position: 'Crew', count: 20, avgSalary: 25 },
];

const COLORS = ['#a18072', '#bfa094', '#d2bab0', '#e0cec7', '#eaddd7'];

const Employees = () => {
  return (
    <Loading>
    <div className="space-y-8">
      <div className="bg-white rounded-lg justify-center shadow-md p-6">
        <h1 className="text-2xl font-bold mb-6">Management Pegawai</h1>

        <div className="grid grid-cols-1 flex justify-center items-center h-[400px] w-full lg:grid-cols-2 gap-8 overflow-x-auto">
          {/* Position Distribution Chart */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Distribusi Posisi</h2>
            <PieChart width={400} height={280}>
              <Pie
                data={employeeData}
                cx={200}
                cy={150}
                labelLine={false}
                label={({ name, percent }) =>
                  `${name} (${(percent * 100).toFixed(0)}%)`
                }
                outerRadius={100}
                fill="#8884d8"
                dataKey="count"
              >
                {employeeData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={COLORS[index % COLORS.length]}
                  />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </div>

          {/* Salary Distribution Chart */}
          <div>
            <h2 className="text-xl font-semibold mb-4">
              Rata-rata Gaji (Jabatan)
            </h2>
            <BarChart width={400} height={300} data={employeeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="position"
                angle={0}
                textAnchor="middle"
                height={80}
              />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar
                dataKey="avgSalary"
                fill="#a18072"
                name="Rata-Rata Gaji (Juta)"
              />
            </BarChart>
          </div>
        </div>
      </div>

      {/* Employee Table */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold mb-4">Overview Pegawai</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Jabatan
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Jumlah Pegawai
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Gaji Rata-Rata
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {employeeData.map((position, index) => (
                <tr key={index}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {position.position}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {position.count}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    Rp. {position.avgSalary.toLocaleString()}.000.000,00
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
    </Loading>
  );
};

export default Employees;
