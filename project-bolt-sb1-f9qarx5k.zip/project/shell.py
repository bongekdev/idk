#!/usr/bin/env python3
# Main shell script for Metasploit-like framework

import os
import sys
import cmd
import importlib.util
import json
from pathlib import Path
from termcolor import colored

# Try to import readline, fall back to pyreadline3 if not available
try:
    import readline
except ImportError:
    try:
        import pyreadline3 as readline
    except ImportError:
        print(colored("[-] Warning: Neither readline nor pyreadline3 could be imported. Command history will be disabled.", 'yellow'))
        readline = None

from core.module_manager import ModuleManager
from core.command_handler import CommandHandler
from core.tool_loader import ToolLoader
from core.banner import print_banner

class MetasploitLikeShell(cmd.Cmd):
    """Main shell class for the Metasploit-like framework"""
    
    def __init__(self):
        super().__init__()
        self.module_manager = ModuleManager()
        self.command_handler = CommandHandler(self)
        self.tool_loader = ToolLoader()
        
        self.current_module = None
        self.options = {}
        
        # Set up command history if readline is available
        if readline:
            histfile = os.path.join(os.path.expanduser("~"), ".msf_shell_history")
            try:
                readline.read_history_file(histfile)
                readline.set_history_length(1000)
            except FileNotFoundError:
                pass
            
            # Register exit function to save history
            import atexit
            atexit.register(readline.write_history_file, histfile)
        
        # Load available modules
        self.load_modules()
        
        # Set prompt
        self.update_prompt()
    
    def update_prompt(self):
        """Update the command prompt based on current context"""
        if self.current_module:
            module_name = colored(self.current_module.name, 'red')
            self.prompt = f"msf ({module_name}) > "
        else:
            self.prompt = colored("msf > ", 'blue')
    
    def load_modules(self):
        """Load all available modules"""
        modules_dir = Path("modules")
        if not modules_dir.exists():
            modules_dir.mkdir(parents=True)
            print(colored("[*] Created modules directory", 'yellow'))
        
        self.module_manager.discover_modules()
        print(colored(f"[*] Loaded {len(self.module_manager.modules)} modules", 'green'))
    
    def emptyline(self):
        """Do nothing on empty line"""
        pass
    
    def default(self, line):
        """Handle unknown commands"""
        print(colored(f"[-] Unknown command: {line}", 'red'))
        print(colored("Type 'help' for a list of available commands", 'yellow'))
    
    def do_exit(self, arg):
        """Exit the shell"""
        print(colored("[*] Exiting...", 'yellow'))
        return True
    
    def do_quit(self, arg):
        """Alias for exit"""
        return self.do_exit(arg)
    
    def do_help(self, arg):
        """Show help information"""
        if arg:
            self.command_handler.handle_help(arg)
        else:
            print(colored("\nCore Commands:", 'green'))
            print("=" * 60)
            cmd_list = [
                ("help", "Display this help menu"),
                ("use <module>", "Select a module to use"),
                ("show modules", "Show available modules"),
                ("show options", "Show current module options"),
                ("set <option> <value>", "Set an option for the current module"),
                ("run", "Run the current module with set options"),
                ("back", "Move back from the current context"),
                ("exit", "Exit the console"),
                ("add_tool", "Add a new tool to the framework")
            ]
            
            for cmd, desc in cmd_list:
                print(f"{colored(cmd.ljust(20), 'cyan')} {desc}")
            print()
    
    def do_use(self, arg):
        """Select a module to use"""
        if not arg:
            print(colored("[-] Usage: use <module>", 'red'))
            return
        
        module = self.module_manager.get_module(arg)
        if module:
            self.current_module = module
            self.options = module.options.copy()
            self.update_prompt()
            print(colored(f"[*] Using module: {module.name}", 'green'))
        else:
            print(colored(f"[-] Module '{arg}' not found", 'red'))
    
    def do_show(self, arg):
        """Show various framework information"""
        if arg == "modules":
            self.module_manager.list_modules()
        elif arg == "options":
            if self.current_module:
                self.current_module.show_options()
            else:
                print(colored("[-] No module selected", 'red'))
        else:
            print(colored("[-] Usage: show <modules|options>", 'red'))
    
    def do_set(self, arg):
        """Set a module option"""
        if not self.current_module:
            print(colored("[-] No module selected", 'red'))
            return
            
        args = arg.split(maxsplit=1)
        if len(args) < 2:
            print(colored("[-] Usage: set <option> <value>", 'red'))
            return
            
        option, value = args
        self.current_module.set_option(option, value)
    
    def do_run(self, arg):
        """Run the selected module"""
        if not self.current_module:
            print(colored("[-] No module selected", 'red'))
            return
            
        self.current_module.run()
    
    def do_back(self, arg):
        """Move back from the current context"""
        if self.current_module:
            self.current_module = None
            self.options = {}
            self.update_prompt()
            print(colored("[*] Returned to main context", 'yellow'))
    
    def do_add_tool(self, arg):
        """Add a new tool to the framework"""
        self.tool_loader.interactive_add_tool()

def main():
    """Main function to start the shell"""
    print_banner()
    shell = MetasploitLikeShell()
    
    try:
        shell.cmdloop()
    except KeyboardInterrupt:
        print("\n[*] Interrupted, exiting...")
    except Exception as e:
        print(colored(f"[-] Error: {str(e)}", 'red'))
        sys.exit(1)

if __name__ == "__main__":
    main()