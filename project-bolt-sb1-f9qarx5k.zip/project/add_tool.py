#!/usr/bin/env python3
# Script to add a new tool to the framework

import sys
import os
from core.tool_loader import ToolLoader

def print_usage():
    """Print usage information"""
    print("Usage: python add_tool.py <path> [options]")
    print("\nOptions:")
    print("  --name=NAME            Name of the tool")
    print("  --category=CATEGORY    Category for the tool (default: uncategorized)")
    print("  --description=DESC     Description of the tool")
    print("  --author=AUTHOR        Author name")
    print("  --version=VERSION      Tool version")
    print("  --option=NAME:REQ:DEF:DESC  Add an option (can be used multiple times)")
    print("                         NAME: Option name")
    print("                         REQ: Required (true/false)")
    print("                         DEF: Default value (or 'none')")
    print("                         DESC: Description")
    print("\nExample:")
    print("  python add_tool.py /path/to/script.py --name=MyScanner --category=scanner \\")
    print("    --option=TARGET:true:none:Target host to scan \\")
    print("    --option=PORT:false:80:Target port")

def main():
    """Main function to add a tool from command line"""
    if len(sys.argv) < 2:
        print_usage()
        sys.exit(1)
    
    path = sys.argv[1]
    if not os.path.exists(path):
        print(f"Error: File not found: {path}")
        sys.exit(1)
    
    # Parse arguments
    name = None
    category = "uncategorized"
    description = None
    author = None
    version = None
    options = {}
    
    for arg in sys.argv[2:]:
        if arg.startswith("--name="):
            name = arg[7:]
        elif arg.startswith("--category="):
            category = arg[11:]
        elif arg.startswith("--description="):
            description = arg[14:]
        elif arg.startswith("--author="):
            author = arg[9:]
        elif arg.startswith("--version="):
            version = arg[10:]
        elif arg.startswith("--option="):
            option_parts = arg[9:].split(":", 3)
            if len(option_parts) != 4:
                print(f"Error: Invalid option format: {arg}")
                continue
            
            option_name, required, default, desc = option_parts
            if not option_name:
                continue
                
            required = required.lower() == "true"
            default = None if default.lower() == "none" else default
            
            options[option_name] = {
                "required": required,
                "default": default,
                "description": desc
            }
    
    # Add tool to framework
    loader = ToolLoader()
    success = loader.add_tool_from_script(
        path=path,
        options=options,
        name=name,
        category=category,
        description=description,
        author=author,
        version=version
    )
    
    if success:
        print(f"Tool successfully added from {path}")
    else:
        print(f"Failed to add tool from {path}")
        sys.exit(1)

if __name__ == "__main__":
    main()