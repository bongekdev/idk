#!/usr/bin/env python3
# Command handler for processing user input

from termcolor import colored

class CommandHandler:
    """Handler for processing commands in the shell"""
    
    def __init__(self, shell):
        self.shell = shell
        self.commands = {
            'help': self.handle_help,
            'use': self.handle_use,
            'show': self.handle_show,
            'set': self.handle_set,
            'run': self.handle_run,
            'back': self.handle_back,
            'exit': self.handle_exit,
            'add_tool': self.handle_add_tool
        }
    
    def handle_command(self, command, args):
        """Handle a command with arguments"""
        if command in self.commands:
            self.commands[command](args)
        else:
            print(colored(f"[-] Unknown command: {command}", 'red'))
    
    def handle_help(self, args):
        """Handle help command"""
        if args:
            cmd = args.split()[0]
            if cmd in self.commands:
                help_text = getattr(self.shell, f"help_{cmd}", None)
                if help_text:
                    print(help_text)
                else:
                    print(colored(f"[*] No detailed help available for '{cmd}'", 'yellow'))
            else:
                print(colored(f"[-] Unknown command: {cmd}", 'red'))
        else:
            self.shell.do_help("")
    
    def handle_use(self, args):
        """Handle use command"""
        self.shell.do_use(args)
    
    def handle_show(self, args):
        """Handle show command"""
        self.shell.do_show(args)
    
    def handle_set(self, args):
        """Handle set command"""
        self.shell.do_set(args)
    
    def handle_run(self, args):
        """Handle run command"""
        self.shell.do_run(args)
    
    def handle_back(self, args):
        """Handle back command"""
        self.shell.do_back(args)
    
    def handle_exit(self, args):
        """Handle exit command"""
        return self.shell.do_exit(args)
    
    def handle_add_tool(self, args):
        """Handle add_tool command"""
        self.shell.do_add_tool(args)

    def complete_command(self, command, text, line, begidx, endidx):
        """Provide tab completion for a command"""
        if command == 'use':
            return [m for m in self.shell.module_manager.modules.keys() if m.startswith(text)]
        elif command == 'show':
            return [opt for opt in ['modules', 'options'] if opt.startswith(text)]
        elif command == 'set' and self.shell.current_module:
            args = line.split()
            if len(args) == 2:  # Only the command and text
                return [opt for opt in self.shell.current_module.options.keys() if opt.startswith(text)]
        return []