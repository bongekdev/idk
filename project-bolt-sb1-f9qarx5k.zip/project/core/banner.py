#!/usr/bin/env python3
# Banner for the Metasploit-like shell

import random
from termcolor import colored

def print_banner():
    """Print a fancy banner for the shell"""
    version = "1.0.0"
    
    banners = [
        """
    ███╗   ███╗███████╗███████╗    ███████╗██╗  ██╗███████╗██╗     ██╗     
    ████╗ ████║██╔════╝██╔════╝    ██╔════╝██║  ██║██╔════╝██║     ██║     
    ██╔████╔██║███████╗█████╗      ███████╗███████║█████╗  ██║     ██║     
    ██║╚██╔╝██║╚════██║██╔══╝      ╚════██║██╔══██║██╔══╝  ██║     ██║     
    ██║ ╚═╝ ██║███████║██║         ███████║██║  ██║███████╗███████╗███████╗
    ╚═╝     ╚═╝╚══════╝╚═╝         ╚══════╝╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝
    """,
        
        """
     __  __  ___  ___    ___  _  _  ___  _    _    
    |  \/  |/ __|| __|  / __|| || || __|| |  | |   
    | |\/| |\__ \| _|   \__ \| __ || _| | |__| |__ 
    |_|  |_||___/|_|    |___/|_||_||___||____|____|
    """
    ]
    
    banner = random.choice(banners)
    print(colored(banner, 'red'))
    print(colored(f"       MSF Shell Framework {version} | Type 'help' for commands\n", 'yellow'))
    print(colored("=" * 70, 'blue'))
    print()