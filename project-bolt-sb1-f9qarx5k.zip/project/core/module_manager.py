#!/usr/bin/env python3
# Module manager for loading and managing modules

import os
import importlib.util
import sys
from pathlib import Path
from termcolor import colored

class ModuleManager:
    """Manager for loading and handling modules"""
    
    def __init__(self):
        self.modules = {}
        self.module_paths = {}
    
    def discover_modules(self):
        """Discover and load all available modules"""
        modules_dir = Path("modules")
        if not modules_dir.exists():
            return
        
        # Recursively find all Python files in the modules directory
        module_files = list(modules_dir.glob("**/*.py"))
        
        for module_file in module_files:
            # Skip __init__.py files
            if module_file.name == "__init__.py":
                continue
                
            # Get module name from path
            rel_path = module_file.relative_to(modules_dir)
            module_name = str(rel_path).replace(".py", "").replace(os.path.sep, "/")
            
            try:
                # Load module dynamically
                module = self._load_module_from_path(module_file, module_name)
                if hasattr(module, "MODULE_INFO"):
                    module_info = module.MODULE_INFO
                    module_info['name'] = module_name
                    module_info['path'] = str(module_file)
                    
                    # Create module instance
                    if hasattr(module, "Module"):
                        module_instance = module.Module()
                        module_instance.name = module_name
                        module_instance.info = module_info
                        
                        self.modules[module_name] = module_instance
                        self.module_paths[module_name] = str(module_file)
            except Exception as e:
                print(colored(f"[-] Failed to load module {module_name}: {str(e)}", 'red'))
    
    def _load_module_from_path(self, path, module_name):
        """Load a Python module from file path"""
        spec = importlib.util.spec_from_file_location(f"modules.{module_name}", path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[f"modules.{module_name}"] = module
        spec.loader.exec_module(module)
        return module
    
    def get_module(self, module_name):
        """Get a module by name"""
        return self.modules.get(module_name)
    
    def list_modules(self):
        """List all available modules"""
        if not self.modules:
            print(colored("[*] No modules available", 'yellow'))
            return
            
        print(colored("\nAvailable Modules:", 'green'))
        print("=" * 60)
        
        for name, module in sorted(self.modules.items()):
            description = module.info.get('description', 'No description')
            print(f"{colored(name.ljust(30), 'cyan')} {description}")
        
        print()